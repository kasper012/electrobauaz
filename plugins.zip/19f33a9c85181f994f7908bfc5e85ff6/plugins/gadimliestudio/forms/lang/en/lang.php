<?php

return [
    'fullname.required' => 'Fullname field is required',
    'subject.required' => 'Subject field is required',
    'email.required' => 'Email field is required',
    'email.email' => 'Please enter a valid email address',
    'phone.required' => 'Phone field is required',
    'msg.required' => 'Message field is required',
    'msg.sent' => 'Message sent'
];
