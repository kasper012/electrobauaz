# Social Sharing Buttons for OctoberCMS

## Introduction
Display buttons to share content on different social networks.

Based & inspired on:
- Bootstrap: http://www.himpfen.com/social-sharing-buttons-bootstrap-font-awesome/
- Non Bootstrap: http://schier.co/blog/2014/10/22/pure-html-share-buttons.html
- Simple Sharing Buttons: https://simplesharingbuttons.com/
