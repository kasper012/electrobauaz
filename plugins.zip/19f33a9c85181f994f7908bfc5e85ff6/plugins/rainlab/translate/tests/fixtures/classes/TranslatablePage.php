<?php namespace RainLab\Translate\Tests\Fixtures\Classes;

use Cms\Classes\Page;

class TranslatablePage extends Page
{
    protected $dirName = 'pages';
}
